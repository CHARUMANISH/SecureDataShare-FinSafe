import React, { useState, useEffect } from 'react'
import { FileText, Download, Shield, CheckCircle, AlertTriangle, Calendar, TrendingUp, Users, Database, Activity, Clock, Award } from 'lucide-react'
import { supabase, dbHelpers } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'

interface ComplianceReport {
  id: string
  name: string
  type: string
  period: string
  status: 'completed' | 'in_progress' | 'failed'
  score: number | null
  generatedAt: string | null
  issues: number
  recommendations: number
  user_id: string
  created_at: string
}

interface ComplianceMetric {
  name: string
  status: 'compliant' | 'warning' | 'non_compliant'
  score: number
  description: string
  category: string
}

interface ComplianceStats {
  totalDataShares: number
  activePartners: number
  auditLogs: number
  permissions: number
  overallScore: number
  activeIssues: number
  reportsGenerated: number
  lastAuditDate: string | null
}

export function Compliance() {
  const { user } = useAuth()
  const [reports, setReports] = useState<ComplianceReport[]>([])
  const [metrics, setMetrics] = useState<ComplianceMetric[]>([])
  const [stats, setStats] = useState<ComplianceStats>({
    totalDataShares: 0,
    activePartners: 0,
    auditLogs: 0,
    permissions: 0,
    overallScore: 0,
    activeIssues: 0,
    reportsGenerated: 0,
    lastAuditDate: null
  })
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      fetchComplianceData()
      // Create sample data if needed
      createSampleDataIfNeeded()
    }
  }, [user])

  const createSampleDataIfNeeded = async () => {
    if (!user) return
    
    try {
      const existingShares = await dbHelpers.getDataShares(user.id)
      if (existingShares.length === 0) {
        await dbHelpers.createSampleData(user.id)
        setTimeout(() => fetchComplianceData(), 1000)
      }
    } catch (error) {
      console.error('Error creating sample data:', error)
    }
  }

  const fetchComplianceData = async () => {
    if (!user) return

    try {
      setLoading(true)

      // Fetch compliance stats using helper functions
      const [dataShares, auditLogsRes, permissionsRes] = await Promise.all([
        dbHelpers.getDataShares(user.id),
        supabase.from('audit_logs').select('*').eq('user_id', user.id),
        supabase.from('permissions').select('*').eq('user_id', user.id)
      ])

      const auditLogs = auditLogsRes.data || []
      const permissions = permissionsRes.data || []

      // Calculate unique partners
      const uniquePartners = new Set(dataShares.map(share => share.partner_name))

      // Calculate compliance metrics
      const calculatedMetrics = calculateComplianceMetrics(dataShares, auditLogs, permissions)
      
      // Calculate overall compliance score
      const overallScore = Math.round(
        calculatedMetrics.reduce((sum, metric) => sum + metric.score, 0) / calculatedMetrics.length
      )

      // Count active issues
      const activeIssues = calculatedMetrics.filter(metric => metric.status !== 'compliant').length

      // Get last audit date
      const lastAuditDate = auditLogs.length > 0 
        ? auditLogs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0].created_at
        : null

      setStats({
        totalDataShares: dataShares.length,
        activePartners: uniquePartners.size,
        auditLogs: auditLogs.length,
        permissions: permissions.filter(p => p.granted).length,
        overallScore,
        activeIssues,
        reportsGenerated: 0, // Will be updated when reports are generated
        lastAuditDate
      })

      setMetrics(calculatedMetrics)

      // Generate sample reports based on actual data
      const sampleReports = generateSampleReports(user.id, overallScore, activeIssues, auditLogs.length)
      setReports(sampleReports)

    } catch (error) {
      console.error('Error fetching compliance data:', error)
    } finally {
      setLoading(false)
    }
  }

  const calculateComplianceMetrics = (dataShares: any[], auditLogs: any[], permissions: any[]): ComplianceMetric[] => {
    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
    const recentAudits = auditLogs.filter(log => new Date(log.created_at) > thirtyDaysAgo)

    return [
      {
        name: 'Data Retention Policy',
        status: dataShares.every(share => new Date(share.expires_at) > now) ? 'compliant' : 'warning',
        score: dataShares.length > 0 ? Math.round((dataShares.filter(share => new Date(share.expires_at) > now).length / dataShares.length) * 100) : 100,
        description: 'All data shares have valid expiration dates',
        category: 'Data Management'
      },
      {
        name: 'Access Controls',
        status: permissions.length > 0 ? 'compliant' : 'warning',
        score: permissions.length > 0 ? 98 : 70,
        description: 'Granular permissions are configured for data access',
        category: 'Security'
      },
      {
        name: 'Audit Logging',
        status: recentAudits.length > 0 ? 'compliant' : 'warning',
        score: auditLogs.length > 0 ? 100 : 60,
        description: 'All data access activities are being logged',
        category: 'Monitoring'
      },
      {
        name: 'Data Encryption',
        status: 'compliant',
        score: 95,
        description: 'Data is encrypted in transit and at rest',
        category: 'Security'
      },
      {
        name: 'Consent Management',
        status: permissions.filter(p => p.granted).length > 0 ? 'compliant' : 'warning',
        score: permissions.length > 0 ? Math.round((permissions.filter(p => p.granted).length / permissions.length) * 100) : 85,
        description: 'User consent is properly managed and documented',
        category: 'Privacy'
      },
      {
        name: 'Incident Response',
        status: 'compliant',
        score: 92,
        description: 'Incident response procedures are in place',
        category: 'Security'
      },
      {
        name: 'System Availability',
        status: 'compliant',
        score: 99,
        description: 'System uptime and availability monitoring',
        category: 'Availability'
      },
      {
        name: 'Processing Integrity',
        status: auditLogs.length > 5 ? 'compliant' : 'warning',
        score: auditLogs.length > 5 ? 96 : 75,
        description: 'Data processing integrity and accuracy controls',
        category: 'Processing'
      }
    ]
  }

  const generateSampleReports = (userId: string, overallScore: number, issues: number, auditCount: number): ComplianceReport[] => {
    const currentDate = new Date().toISOString()
    
    return [
      {
        id: '1',
        name: 'GDPR Compliance Report',
        type: 'GDPR',
        period: 'Q4 2024',
        status: 'completed',
        score: Math.max(overallScore - 2, 85),
        generatedAt: currentDate,
        issues: issues,
        recommendations: issues + 1,
        user_id: userId,
        created_at: currentDate
      },
      {
        id: '2',
        name: 'DPDP Act Compliance',
        type: 'DPDP',
        period: 'Q4 2024',
        status: 'completed',
        score: Math.max(overallScore - 5, 80),
        generatedAt: currentDate,
        issues: issues + 1,
        recommendations: issues + 2,
        user_id: userId,
        created_at: currentDate
      },
      {
        id: '3',
        name: 'SOC 2 Type II',
        type: 'SOC2',
        period: 'Annual 2024',
        status: auditCount >= 5 ? 'completed' : 'in_progress',
        score: auditCount >= 5 ? Math.max(overallScore - 1, 88) : null,
        generatedAt: auditCount >= 5 ? currentDate : null,
        issues: auditCount >= 5 ? Math.max(issues - 1, 0) : 0,
        recommendations: auditCount >= 5 ? issues + 1 : 0,
        user_id: userId,
        created_at: currentDate
      }
    ]
  }

  const generateReport = async (type: string) => {
    if (!user) return

    try {
      setGenerating(type)

      // For SOC 2, check if we have enough audit data
      if (type === 'SOC2' && stats.auditLogs < 5) {
        alert('SOC 2 Type II requires more audit data. Please ensure you have at least 5 audit log entries to generate a comprehensive report.')
        setGenerating(null)
        return
      }

      // Log the report generation
      await dbHelpers.logAuditEvent(
        user.id,
        'report_generated',
        'compliance_report',
        `${type.toLowerCase()}_${Date.now()}`,
        {
          report_type: type,
          generated_at: new Date().toISOString(),
          user_initiated: true,
          audit_logs_count: stats.auditLogs,
          compliance_score: stats.overallScore
        }
      )

      // Simulate report generation delay
      await new Promise(resolve => setTimeout(resolve, 3000))

      // Refresh compliance data to show the new audit log
      await fetchComplianceData()

      alert(`${type} compliance report generated successfully! ${type === 'SOC2' ? 'SOC 2 Type II report includes security, availability, processing integrity, confidentiality, and privacy controls assessment.' : ''}`)
    } catch (error) {
      console.error('Error generating report:', error)
      alert('Failed to generate report. Please try again.')
    } finally {
      setGenerating(null)
    }
  }

  const downloadReport = async (reportId: string) => {
    if (!user) return
    
    try {
      // Log the download action
      await dbHelpers.logAuditEvent(
        user.id,
        'report_downloaded',
        'compliance_report',
        reportId,
        {
          download_timestamp: new Date().toISOString(),
          file_format: 'CSV'
        }
      )

      // Generate comprehensive report content
      const report = reports.find(r => r.id === reportId)
      if (report) {
        let csvContent = `Report Name,${report.name}\nType,${report.type}\nPeriod,${report.period}\nScore,${report.score}%\nIssues,${report.issues}\nRecommendations,${report.recommendations}\nGenerated,${report.generatedAt}\n\n`
        
        // Add compliance metrics
        csvContent += 'Compliance Metrics\n'
        csvContent += 'Metric,Status,Score,Category\n'
        metrics.forEach(metric => {
          csvContent += `${metric.name},${metric.status},${metric.score}%,${metric.category}\n`
        })

        // Add SOC 2 specific details if applicable
        if (report.type === 'SOC2') {
          csvContent += '\nSOC 2 Trust Service Criteria\n'
          csvContent += 'Security,Compliant,95%\n'
          csvContent += 'Availability,Compliant,99%\n'
          csvContent += 'Processing Integrity,Compliant,96%\n'
          csvContent += 'Confidentiality,Compliant,94%\n'
          csvContent += 'Privacy,Compliant,92%\n'
        }
        
        const blob = new Blob([csvContent], { type: 'text/csv' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${report.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error('Error downloading report:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800'
      case 'in_progress': return 'bg-yellow-100 text-yellow-800'
      case 'failed': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getComplianceColor = (status: string) => {
    switch (status) {
      case 'compliant': return 'text-green-600'
      case 'warning': return 'text-yellow-600'
      case 'non_compliant': return 'text-red-600'
      default: return 'text-gray-600'
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 95) return 'text-green-600'
    if (score >= 85) return 'text-yellow-600'
    return 'text-red-600'
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Compliance Dashboard</h1>
                <p className="mt-2 text-sm text-gray-600">
                  Monitor compliance status and generate regulatory reports
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="h-8 w-8 text-blue-600" />
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">Compliance Score</p>
                  <p className={`text-2xl font-bold ${getScoreColor(stats.overallScore)}`}>
                    {stats.overallScore}%
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Shield className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Overall Compliance</p>
                  <p className={`text-2xl font-bold ${getScoreColor(stats.overallScore)}`}>
                    {stats.overallScore}%
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Issues</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activeIssues}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Reports Generated</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {reports.filter(r => r.status === 'completed').length}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Activity className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Audit Events</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.auditLogs}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Compliance Metrics by Category */}
          <div className="bg-white rounded-xl shadow-sm mb-8 border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Compliance Metrics</h3>
              <p className="text-sm text-gray-500 mt-1">Real-time compliance status across all categories</p>
            </div>
            <div className="p-6">
              {/* Group metrics by category */}
              {['Security', 'Data Management', 'Privacy', 'Monitoring', 'Availability', 'Processing'].map(category => {
                const categoryMetrics = metrics.filter(m => m.category === category)
                if (categoryMetrics.length === 0) return null
                
                return (
                  <div key={category} className="mb-6 last:mb-0">
                    <h4 className="text-md font-medium text-gray-900 mb-3">{category}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {categoryMetrics.map((metric, index) => (
                        <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-all duration-200 bg-gray-50">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="text-sm font-medium text-gray-900">{metric.name}</h5>
                            <span className={`${getComplianceColor(metric.status)}`}>
                              {metric.status === 'compliant' ? (
                                <CheckCircle className="h-5 w-5" />
                              ) : (
                                <AlertTriangle className="h-5 w-5" />
                              )}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500 mb-3">{metric.description}</p>
                          <div className="flex items-center">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full transition-all duration-500 ${
                                  metric.score >= 95 ? 'bg-green-500' : metric.score >= 85 ? 'bg-yellow-500' : 'bg-red-500'
                                }`}
                                style={{ width: `${metric.score}%` }}
                              />
                            </div>
                            <span className={`ml-2 text-sm font-medium ${getScoreColor(metric.score)}`}>
                              {metric.score}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Report Generation */}
          <div className="bg-white rounded-xl shadow-sm mb-8 border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Generate Compliance Reports</h3>
              <p className="text-sm text-gray-500 mt-1">Create detailed compliance reports for regulatory requirements</p>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200">
                  <div className="text-center">
                    <div className="mx-auto w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 mb-2">GDPR Report</h4>
                    <p className="text-sm text-gray-500 mb-4">European data protection compliance assessment</p>
                    <button
                      onClick={() => generateReport('GDPR')}
                      disabled={generating === 'GDPR'}
                      className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      {generating === 'GDPR' ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Generating...
                        </div>
                      ) : (
                        'Generate Report'
                      )}
                    </button>
                  </div>
                </div>

                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200">
                  <div className="text-center">
                    <div className="mx-auto w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                      <FileText className="h-6 w-6 text-green-600" />
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 mb-2">DPDP Act Report</h4>
                    <p className="text-sm text-gray-500 mb-4">Indian data protection compliance assessment</p>
                    <button
                      onClick={() => generateReport('DPDP')}
                      disabled={generating === 'DPDP'}
                      className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      {generating === 'DPDP' ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Generating...
                        </div>
                      ) : (
                        'Generate Report'
                      )}
                    </button>
                  </div>
                </div>

                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 hover:border-blue-300 hover:bg-blue-50 transition-all duration-200">
                  <div className="text-center">
                    <div className="mx-auto w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                      <Shield className="h-6 w-6 text-purple-600" />
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 mb-2">SOC 2 Type II</h4>
                    <p className="text-sm text-gray-500 mb-4">Security, availability & processing integrity controls</p>
                    <div className="mb-3">
                      <div className="text-xs text-gray-500">
                        Audit logs required: {stats.auditLogs}/5
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${Math.min((stats.auditLogs / 5) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => generateReport('SOC2')}
                      disabled={generating === 'SOC2'}
                      className="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      {generating === 'SOC2' ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Generating...
                        </div>
                      ) : (
                        'Generate Report'
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Reports */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Recent Reports</h3>
                  <p className="text-sm text-gray-500 mt-1">Generated compliance reports and their status</p>
                </div>
                {stats.lastAuditDate && (
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Last audit activity</p>
                    <p className="text-sm font-medium text-gray-900">
                      {new Date(stats.lastAuditDate).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Report
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Period
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Score
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Issues
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Generated
                    </th>
                    <th className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`p-2 rounded-lg mr-3 ${
                            report.type === 'GDPR' ? 'bg-blue-100' :
                            report.type === 'DPDP' ? 'bg-green-100' :
                            'bg-purple-100'
                          }`}>
                            <FileText className={`h-4 w-4 ${
                              report.type === 'GDPR' ? 'text-blue-600' :
                              report.type === 'DPDP' ? 'text-green-600' :
                              'text-purple-600'
                            }`} />
                          </div>
                          <div className="text-sm font-medium text-gray-900">{report.name}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          report.type === 'GDPR' ? 'bg-blue-100 text-blue-800' :
                          report.type === 'DPDP' ? 'bg-green-100 text-green-800' :
                          'bg-purple-100 text-purple-800'
                        }`}>
                          {report.type}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {report.period}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(report.status)}`}>
                          {report.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {report.score ? (
                          <div className="flex items-center">
                            <span className={`font-medium ${getScoreColor(report.score)}`}>
                              {report.score}%
                            </span>
                            {report.score >= 95 ? (
                              <TrendingUp className="h-4 w-4 text-green-500 ml-1" />
                            ) : report.score >= 85 ? (
                              <TrendingUp className="h-4 w-4 text-yellow-500 ml-1" />
                            ) : (
                              <AlertTriangle className="h-4 w-4 text-red-500 ml-1" />
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400">Pending</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                          report.issues === 0 ? 'bg-green-100 text-green-800' : 
                          report.issues <= 2 ? 'bg-yellow-100 text-yellow-800' : 
                          'bg-red-100 text-red-800'
                        }`}>
                          {report.issues} issues
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {report.generatedAt ? (
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-gray-400 mr-1" />
                            {new Date(report.generatedAt).toLocaleDateString()}
                          </div>
                        ) : (
                          <span className="text-gray-400">N/A</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {report.status === 'completed' && (
                          <button
                            onClick={() => downloadReport(report.id)}
                            className="text-blue-600 hover:text-blue-900 flex items-center gap-1 transition-colors"
                          >
                            <Download className="h-4 w-4" />
                            Download
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {reports.length === 0 && (
              <div className="px-6 py-12 text-center">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">No compliance reports generated yet</p>
                <p className="text-sm text-gray-400 mt-1">Generate your first report using the buttons above</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
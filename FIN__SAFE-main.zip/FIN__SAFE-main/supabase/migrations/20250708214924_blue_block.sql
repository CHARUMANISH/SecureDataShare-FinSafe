/*
  # Add file upload support to data shares

  1. Database Changes
    - Add `details` column to `data_shares` table to store file metadata
    - Add indexes for better performance

  2. Storage Setup
    - Note: Storage bucket and policies need to be created via Supabase Dashboard
    - This migration prepares the database structure for file uploads

  3. Instructions for Manual Setup
    - Go to Supabase Dashboard > Storage
    - Create bucket named 'data-shares' with public access
    - Set up RLS policies as described in comments below
*/

-- Add details column to data_shares table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'details'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN details jsonb DEFAULT '{}';
  END IF;
END $$;

-- Add index for details column for better performance
CREATE INDEX IF NOT EXISTS idx_data_shares_details ON data_shares USING gin (details);

-- Update the existing data_shares table to ensure all required columns exist
DO $$
BEGIN
  -- Ensure last_accessed column exists and has proper default
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'last_accessed'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN last_accessed timestamptz DEFAULT now();
  END IF;
END $$;

/*
  MANUAL STORAGE SETUP REQUIRED:
  
  Since storage policies cannot be created via migrations, please follow these steps:
  
  1. Go to Supabase Dashboard > Storage
  2. Create a new bucket with these settings:
     - Name: data-shares
     - Public: true
     - File size limit: 50MB
     - Allowed MIME types: application/pdf,application/json,text/csv,application/zip,text/plain
  
  3. Create the following RLS policies for the bucket:
  
  Policy 1: "Users can upload files to own folder"
  - Operation: INSERT
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  Policy 2: "Users can view own files"
  - Operation: SELECT
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  Policy 3: "Users can delete own files"
  - Operation: DELETE
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  Policy 4: "Users can update own files"
  - Operation: UPDATE
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
*/

-- Create a function to help with file cleanup (optional)
CREATE OR REPLACE FUNCTION cleanup_expired_files()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- This function can be used to clean up files from expired data shares
  -- Implementation would require storage API calls which need to be done from application code
  RAISE NOTICE 'File cleanup should be implemented in application code using storage API';
END;
$$;
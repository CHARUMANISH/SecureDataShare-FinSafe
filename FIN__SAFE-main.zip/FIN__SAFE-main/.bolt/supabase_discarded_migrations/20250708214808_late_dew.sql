/*
  # Create Storage Bucket for Data Shares

  1. Storage Setup
    - Create 'data-shares' bucket for file uploads
    - Enable public access for file URLs
    - Set up RLS policies for secure access

  2. Security
    - Users can only upload to their own folder
    - Users can only access their own files
    - Proper file type and size restrictions
*/

-- Create the storage bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('data-shares', 'data-shares', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy to allow users to upload files to their own folder
CREATE POLICY "Users can upload files to own folder" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'data-shares' AND 
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow users to view their own files
CREATE POLICY "Users can view own files" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'data-shares' AND 
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow users to delete their own files
CREATE POLICY "Users can delete own files" ON storage.objects
FOR DELETE TO authenticated
USING (
  bucket_id = 'data-shares' AND 
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow users to update their own files
CREATE POLICY "Users can update own files" ON storage.objects
FOR UPDATE TO authenticated
USING (
  bucket_id = 'data-shares' AND 
  (storage.foldername(name))[1] = auth.uid()::text
);
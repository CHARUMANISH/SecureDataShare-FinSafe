import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables')
  // Use fallback values for development
  const fallbackUrl = 'https://dfuwaihqcxfjymwplgds.supabase.co'
  const fallbackKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRmdXdhaWhxY3hmanlud3BsZ2RzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzY4NzY5NzQsImV4cCI6MjA1MjQ1Mjk3NH0.Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8'
  
  console.warn('Using fallback Supabase configuration for development')
}

export const supabase = createClient(
  supabaseUrl || 'https://dfuwaihqcxfjymwplgds.supabase.co',
  supabaseAnonKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRmdXdhaWhxY3hmanlud3BsZ2RzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzY4NzY5NzQsImV4cCI6MjA1MjQ1Mjk3NH0.Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8Ej8',
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    },
    db: {
      schema: 'public'
    },
    global: {
      headers: {
        'X-Client-Info': 'finsafe-web-app'
      }
    }
  }
)

// Enhanced database types with proper relationships
export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          company_name: string
          contact_email: string
          phone: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          company_name?: string
          contact_email?: string
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          company_name?: string
          contact_email?: string
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      data_shares: {
        Row: {
          id: string
          user_id: string
          partner_name: string
          data_type: string
          purpose: string
          status: 'active' | 'revoked' | 'pending'
          created_at: string
          expires_at: string
          last_accessed: string
          details: Record<string, any> | null
        }
        Insert: {
          id?: string
          user_id: string
          partner_name: string
          data_type: string
          purpose: string
          status?: 'active' | 'revoked' | 'pending'
          created_at?: string
          expires_at: string
          last_accessed?: string
          details?: Record<string, any> | null
        }
        Update: {
          id?: string
          user_id?: string
          partner_name?: string
          data_type?: string
          purpose?: string
          status?: 'active' | 'revoked' | 'pending'
          created_at?: string
          expires_at?: string
          last_accessed?: string
          details?: Record<string, any> | null
        }
      }
      audit_logs: {
        Row: {
          id: string
          user_id: string
          action: string
          resource_type: string
          resource_id: string
          details: Record<string, any> | null
          ip_address: string
          user_agent: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          action: string
          resource_type: string
          resource_id: string
          details?: Record<string, any> | null
          ip_address?: string
          user_agent?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          action?: string
          resource_type?: string
          resource_id?: string
          details?: Record<string, any> | null
          ip_address?: string
          user_agent?: string
          created_at?: string
        }
      }
      permissions: {
        Row: {
          id: string
          user_id: string
          partner_id: string
          data_type: string
          granted: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          partner_id: string
          data_type: string
          granted?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          partner_id?: string
          data_type?: string
          granted?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}

// Helper functions for common database operations
export const dbHelpers = {
  // Profile operations
  async createProfile(userId: string, data: Partial<Database['public']['Tables']['profiles']['Insert']>) {
    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .insert({
          user_id: userId,
          company_name: data.company_name || '',
          contact_email: data.contact_email || '',
          phone: data.phone || null,
          ...data
        })
        .select()
        .single()

      if (error) {
        console.error('Error creating profile:', error)
        throw error
      }
      return profile
    } catch (error) {
      console.error('Profile creation failed:', error)
      throw error
    }
  },

  async getProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)

      if (error) {
        console.error('Error fetching profile:', error)
        return null
      }
      return data?.[0] || null
    } catch (error) {
      console.error('Profile fetch failed:', error)
      return null
    }
  },

  // Data share operations
  async createDataShare(data: Database['public']['Tables']['data_shares']['Insert']) {
    try {
      const { data: dataShare, error } = await supabase
        .from('data_shares')
        .insert(data)
        .select()
        .single()

      if (error) {
        console.error('Error creating data share:', error)
        throw error
      }
      return dataShare
    } catch (error) {
      console.error('Data share creation failed:', error)
      throw error
    }
  },

  async getDataShares(userId: string) {
    try {
      const { data, error } = await supabase
        .from('data_shares')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching data shares:', error)
        return []
      }
      return data || []
    } catch (error) {
      console.error('Data shares fetch failed:', error)
      return []
    }
  },

  // Permission operations
  async updatePermission(userId: string, partnerId: string, dataType: string, granted: boolean) {
    try {
      const { data: existing } = await supabase
        .from('permissions')
        .select('id')
        .eq('user_id', userId)
        .eq('partner_id', partnerId)
        .eq('data_type', dataType)
        .single()

      if (existing) {
        const { data, error } = await supabase
          .from('permissions')
          .update({ granted, updated_at: new Date().toISOString() })
          .eq('id', existing.id)
          .select()
          .single()

        if (error) {
          console.error('Error updating permission:', error)
          throw error
        }
        return data
      } else {
        const { data, error } = await supabase
          .from('permissions')
          .insert({
            user_id: userId,
            partner_id: partnerId,
            data_type: dataType,
            granted
          })
          .select()
          .single()

        if (error) {
          console.error('Error creating permission:', error)
          throw error
        }
        return data
      }
    } catch (error) {
      console.error('Permission update failed:', error)
      throw error
    }
  },

  async getPermissions(userId: string) {
    try {
      const { data, error } = await supabase
        .from('permissions')
        .select('*')
        .eq('user_id', userId)

      if (error) {
        console.error('Error fetching permissions:', error)
        return []
      }
      return data || []
    } catch (error) {
      console.error('Permissions fetch failed:', error)
      return []
    }
  },

  // Audit log operations
  async logAuditEvent(
    userId: string,
    action: string,
    resourceType: string,
    resourceId: string,
    details?: Record<string, any>
  ) {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .insert({
          user_id: userId,
          action,
          resource_type: resourceType,
          resource_id: resourceId,
          details: details || {},
          ip_address: 'unknown', // In production, get from request
          user_agent: navigator.userAgent
        })

      if (error) {
        console.error('Failed to log audit event:', error)
      }
    } catch (error) {
      console.error('Error logging audit event:', error)
    }
  },

  async getAuditLogs(userId: string, limit = 100) {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(limit)

      if (error) {
        console.error('Error fetching audit logs:', error)
        return []
      }
      return data || []
    } catch (error) {
      console.error('Audit logs fetch failed:', error)
      return []
    }
  },

  // Health check
  async healthCheck() {
    try {
      // Test database connection
      const { error: dbError } = await supabase
        .from('profiles')
        .select('id')
        .limit(1)
      
      // Test storage connection
      const { error: storageError } = await supabase.storage.listBuckets()

      return { 
        healthy: !dbError && !storageError, 
        database: !dbError,
        storage: !storageError,
        error: dbError || storageError 
      }
    } catch (error) {
      return { 
        healthy: false, 
        database: false,
        storage: false,
        error 
      }
    }
  },

  // Create sample data for demo
  async createSampleData(userId: string) {
    try {
      // Create sample data shares
      const sampleShares = [
        {
          user_id: userId,
          partner_name: 'Bank A',
          data_type: 'Account Balance',
          purpose: 'Credit assessment for loan application',
          status: 'active' as const,
          expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          details: { created_via: 'sample_data' }
        },
        {
          user_id: userId,
          partner_name: 'Credit Union',
          data_type: 'Transaction History',
          purpose: 'Financial analysis for investment advisory',
          status: 'pending' as const,
          expires_at: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(),
          details: { created_via: 'sample_data' }
        },
        {
          user_id: userId,
          partner_name: 'Fintech Co',
          data_type: 'Credit Score',
          purpose: 'Risk assessment for insurance premium calculation',
          status: 'revoked' as const,
          expires_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
          details: { created_via: 'sample_data' }
        }
      ]

      for (const share of sampleShares) {
        await this.createDataShare(share)
      }

      // Create sample permissions
      const partners = ['bank_a', 'credit_union', 'fintech_co']
      const dataTypes = ['account_balance', 'transaction_history', 'credit_score']

      for (const partner of partners) {
        for (const dataType of dataTypes) {
          await this.updatePermission(userId, partner, dataType, Math.random() > 0.5)
        }
      }

      // Create sample audit logs
      const auditEvents = [
        { action: 'data_share_created', resource_type: 'data_share', resource_id: 'sample_1' },
        { action: 'permission_granted', resource_type: 'permission', resource_id: 'sample_2' },
        { action: 'data_access', resource_type: 'data_share', resource_id: 'sample_3' },
        { action: 'permission_revoked', resource_type: 'permission', resource_id: 'sample_4' }
      ]

      for (const event of auditEvents) {
        await this.logAuditEvent(userId, event.action, event.resource_type, event.resource_id, {
          created_via: 'sample_data',
          timestamp: new Date().toISOString()
        })
      }

      console.log('Sample data created successfully')
    } catch (error) {
      console.error('Error creating sample data:', error)
    }
  }
}
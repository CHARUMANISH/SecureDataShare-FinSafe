/*
  # Storage Setup for File Uploads

  This migration provides instructions for manual storage setup since Supabase doesn't allow
  creating storage buckets via SQL migrations.

  ## Manual Setup Required:

  1. Go to Supabase Dashboard → Storage
  2. Create bucket named "data-shares" with these settings:
     - Name: data-shares
     - Public: ✅ (enabled)
     - File size limit: 50MB
     - Allowed MIME types: application/pdf,application/json,text/csv,application/zip,text/plain

  3. Set up RLS policies in Storage → data-shares → Policies:

  Policy 1: "Users can upload to own folder"
  - Operation: INSERT
  - Target roles: authenticated
  - Policy: bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text

  Policy 2: "Users can view own files"
  - Operation: SELECT  
  - Target roles: authenticated
  - Policy: bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text

  Policy 3: "Users can delete own files"
  - Operation: DELETE
  - Target roles: authenticated
  - Policy: bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text

  Policy 4: "Users can update own files"
  - Operation: UPDATE
  - Target roles: authenticated
  - Policy: bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
*/

-- Ensure data_shares table has details column for file metadata
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'details'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN details jsonb DEFAULT '{}';
  END IF;
END $$;

-- Create index for details column
CREATE INDEX IF NOT EXISTS idx_data_shares_details ON data_shares USING gin (details);

-- Update existing records
UPDATE data_shares SET details = '{}' WHERE details IS NULL;

-- Create function to validate storage setup
CREATE OR REPLACE FUNCTION validate_storage_setup()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
BEGIN
  result := jsonb_build_object(
    'bucket_required', 'data-shares',
    'setup_complete', false,
    'instructions', jsonb_build_array(
      'Go to Supabase Dashboard → Storage',
      'Create bucket named "data-shares"',
      'Enable public access',
      'Set file size limit to 50MB',
      'Add RLS policies for authenticated users'
    )
  );
  
  RETURN result;
END;
$$;

-- Grant permissions
GRANT EXECUTE ON FUNCTION validate_storage_setup() TO authenticated;
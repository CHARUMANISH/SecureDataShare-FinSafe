import { useState, useEffect } from 'react'
import { User, AuthError } from '@supabase/supabase-js'
import { supabase, dbHelpers } from '../lib/supabase'

interface AuthState {
  user: User | null
  loading: boolean
  error: string | null
}

export function useAuth() {
  const [state, setState] = useState<AuthState>({
    user: null,
    loading: true,
    error: null
  })

  useEffect(() => {
    let mounted = true

    // Get initial session
    const getInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession()
        
        if (!mounted) return

        if (error) {
          console.error('Error getting session:', error)
          setState(prev => ({ ...prev, error: error.message, loading: false }))
          return
        }

        setState(prev => ({ 
          ...prev, 
          user: session?.user ?? null, 
          loading: false,
          error: null 
        }))

        // Create profile if user exists but no profile
        if (session?.user) {
          try {
            const profile = await dbHelpers.getProfile(session.user.id)
            if (!profile) {
              await dbHelpers.createProfile(session.user.id, {
                contact_email: session.user.email || ''
              })
            }
          } catch (profileError) {
            console.error('Error handling profile:', profileError)
            // Don't fail auth if profile creation fails
          }
        }
      } catch (error) {
        if (!mounted) return
        console.error('Error in getInitialSession:', error)
        setState(prev => ({ 
          ...prev, 
          error: 'Failed to initialize authentication', 
          loading: false 
        }))
      }
    }

    getInitialSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return

        try {
          setState(prev => ({ 
            ...prev, 
            user: session?.user ?? null, 
            loading: false,
            error: null 
          }))

          // Handle sign in - create profile if needed
          if (event === 'SIGNED_IN' && session?.user) {
            try {
              const profile = await dbHelpers.getProfile(session.user.id)
              if (!profile) {
                await dbHelpers.createProfile(session.user.id, {
                  contact_email: session.user.email || ''
                })
              }

              // Log sign in event
              await dbHelpers.logAuditEvent(
                session.user.id,
                'user_signed_in',
                'auth',
                session.user.id,
                { email: session.user.email }
              )
            } catch (profileError) {
              console.error('Error handling profile on sign in:', profileError)
              // Don't fail auth if profile operations fail
            }
          }

          // Handle sign out
          if (event === 'SIGNED_OUT') {
            setState(prev => ({ ...prev, user: null, error: null }))
          }
        } catch (error) {
          if (!mounted) return
          console.error('Error in auth state change:', error)
          setState(prev => ({ 
            ...prev, 
            error: 'Authentication state change failed' 
          }))
        }
      }
    )

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }))
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password
      })

      if (error) {
        throw error
      }

      return data
    } catch (error) {
      const authError = error as AuthError
      setState(prev => ({ ...prev, error: authError.message, loading: false }))
      throw error
    }
  }

  const signUp = async (email: string, password: string) => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }))
      
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/dashboard`
        }
      })

      if (error) {
        throw error
      }

      return data
    } catch (error) {
      const authError = error as AuthError
      setState(prev => ({ ...prev, error: authError.message, loading: false }))
      throw error
    }
  }

  const signOut = async () => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }))
      
      // Log sign out event if user exists
      if (state.user) {
        try {
          await dbHelpers.logAuditEvent(
            state.user.id,
            'user_signed_out',
            'auth',
            state.user.id
          )
        } catch (auditError) {
          console.error('Error logging sign out:', auditError)
          // Don't fail sign out if audit logging fails
        }
      }

      const { error } = await supabase.auth.signOut()
      
      if (error) {
        throw error
      }
    } catch (error) {
      const authError = error as AuthError
      setState(prev => ({ ...prev, error: authError.message, loading: false }))
      throw error
    }
  }

  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      })

      if (error) {
        throw error
      }
    } catch (error) {
      const authError = error as AuthError
      throw error
    }
  }

  const updatePassword = async (password: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password
      })

      if (error) {
        throw error
      }
    } catch (error) {
      const authError = error as AuthError
      throw error
    }
  }

  return {
    user: state.user,
    loading: state.loading,
    error: state.error,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword
  }
}
/*
  # Complete Backend Fix for finSafe Platform

  1. Database Schema Updates
    - Fix all table structures and constraints
    - Add proper indexes for performance
    - Update RLS policies for security
    - Add trigger functions for automation

  2. Storage Setup
    - Instructions for manual storage bucket creation
    - Proper RLS policies for file access

  3. Data Integrity
    - Foreign key constraints
    - Check constraints for data validation
    - Default values and proper types
*/

-- Create or update trigger function for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Update profiles table structure
ALTER TABLE profiles 
  ALTER COLUMN company_name SET DEFAULT '',
  ALTER COLUMN contact_email SET DEFAULT '',
  ALTER COLUMN phone DROP NOT NULL;

-- Update data_shares table structure
DO $$
BEGIN
  -- Add missing columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'data_shares' AND column_name = 'details'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN details jsonb DEFAULT '{}';
  END IF;
END $$;

-- Update permissions table structure
DO $$
BEGIN
  -- Ensure proper indexes exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'permissions' AND indexname = 'idx_permissions_partner_data_type'
  ) THEN
    CREATE INDEX idx_permissions_partner_data_type ON permissions(partner_id, data_type);
  END IF;
END $$;

-- Update audit_logs table structure
DO $$
BEGIN
  -- Add index for better performance
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'audit_logs' AND indexname = 'idx_audit_logs_action'
  ) THEN
    CREATE INDEX idx_audit_logs_action ON audit_logs(action);
  END IF;
END $$;

-- Ensure all RLS policies are properly set up
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
CREATE POLICY "Users can read own profile" ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Data shares policies
DROP POLICY IF EXISTS "Users can insert own data shares" ON data_shares;
CREATE POLICY "Users can insert own data shares" ON data_shares
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can read own data shares" ON data_shares;
CREATE POLICY "Users can read own data shares" ON data_shares
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own data shares" ON data_shares;
CREATE POLICY "Users can update own data shares" ON data_shares
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Permissions policies
DROP POLICY IF EXISTS "Users can insert own permissions" ON permissions;
CREATE POLICY "Users can insert own permissions" ON permissions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can read own permissions" ON permissions;
CREATE POLICY "Users can read own permissions" ON permissions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own permissions" ON permissions;
CREATE POLICY "Users can update own permissions" ON permissions
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Audit logs policies
DROP POLICY IF EXISTS "Users can insert own audit logs" ON audit_logs;
CREATE POLICY "Users can insert own audit logs" ON audit_logs
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can read own audit logs" ON audit_logs;
CREATE POLICY "Users can read own audit logs" ON audit_logs
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Add some sample data for demo purposes (optional)
DO $$
DECLARE
  sample_user_id uuid;
BEGIN
  -- This will only work if there's at least one user in auth.users
  SELECT id INTO sample_user_id FROM auth.users LIMIT 1;
  
  IF sample_user_id IS NOT NULL THEN
    -- Insert sample data shares if they don't exist
    INSERT INTO data_shares (user_id, partner_name, data_type, purpose, status, expires_at, details)
    SELECT 
      sample_user_id,
      'Demo Bank',
      'Transaction History',
      'Credit assessment for loan application',
      'active',
      CURRENT_DATE + INTERVAL '90 days',
      '{"demo": true, "files_count": 0}'
    WHERE NOT EXISTS (
      SELECT 1 FROM data_shares WHERE user_id = sample_user_id AND partner_name = 'Demo Bank'
    );

    -- Insert sample permissions
    INSERT INTO permissions (user_id, partner_id, data_type, granted)
    SELECT 
      sample_user_id,
      'demo_bank',
      'account_balance',
      true
    WHERE NOT EXISTS (
      SELECT 1 FROM permissions 
      WHERE user_id = sample_user_id AND partner_id = 'demo_bank' AND data_type = 'account_balance'
    );

    -- Insert sample audit log
    INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details)
    SELECT 
      sample_user_id,
      'demo_data_created',
      'system',
      'demo_setup',
      '{"message": "Demo data created for testing", "timestamp": "' || CURRENT_TIMESTAMP || '"}'
    WHERE NOT EXISTS (
      SELECT 1 FROM audit_logs 
      WHERE user_id = sample_user_id AND action = 'demo_data_created'
    );
  END IF;
END $$;
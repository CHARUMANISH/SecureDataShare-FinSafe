import { supabase } from './supabase'

export interface FileUploadResult {
  success: boolean
  url?: string
  error?: string
  fileName?: string
  publicUrl?: string
}

export interface StorageValidation {
  isValid: boolean
  error?: string
  canProceed: boolean
}

export class StorageService {
  private static readonly BUCKET_NAME = 'data-shares'
  private static readonly MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB
  private static readonly ALLOWED_TYPES = {
    'application/pdf': '.pdf',
    'application/json': '.json',
    'text/csv': '.csv',
    'application/zip': '.zip',
    'application/x-zip-compressed': '.zip',
    'text/plain': '.txt',
    'application/vnd.ms-excel': '.xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx'
  }

  static async validateStorageSetup(): Promise<StorageValidation> {
    try {
      // First, try to create the bucket if it doesn't exist
      await this.ensureBucketExists()
      
      // Test bucket access by trying to list files
      const { data, error } = await supabase.storage
        .from(this.BUCKET_NAME)
        .list('', { limit: 1 })

      if (error) {
        console.warn('Storage validation warning:', error.message)
        // Even if there's an error, we can still proceed with uploads
        return {
          isValid: false,
          error: `Storage setup issue: ${error.message}`,
          canProceed: true // Allow proceeding anyway
        }
      }

      return { isValid: true, canProceed: true }
    } catch (error) {
      console.warn('Storage validation error:', error)
      return {
        isValid: false,
        error: `Storage validation failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        canProceed: true // Still allow proceeding
      }
    }
  }

  private static async ensureBucketExists(): Promise<void> {
    try {
      // Try to get bucket info
      const { data: buckets } = await supabase.storage.listBuckets()
      const bucketExists = buckets?.some(bucket => bucket.name === this.BUCKET_NAME)
      
      if (!bucketExists) {
        // Try to create the bucket
        const { error: createError } = await supabase.storage.createBucket(this.BUCKET_NAME, {
          public: true,
          fileSizeLimit: 52428800, // 50MB
          allowedMimeTypes: Object.keys(this.ALLOWED_TYPES)
        })
        
        if (createError) {
          console.warn('Could not create bucket automatically:', createError.message)
        }
      }
    } catch (error) {
      console.warn('Error ensuring bucket exists:', error)
    }
  }

  static validateFile(file: File): { valid: boolean; error?: string } {
    // Check file type
    if (!Object.keys(this.ALLOWED_TYPES).includes(file.type)) {
      return {
        valid: false,
        error: `Unsupported file type: ${file.type}. Allowed: PDF, JSON, CSV, ZIP, TXT, Excel`
      }
    }

    // Check file size
    if (file.size > this.MAX_FILE_SIZE) {
      return {
        valid: false,
        error: `File too large: ${this.formatFileSize(file.size)}. Max: ${this.formatFileSize(this.MAX_FILE_SIZE)}`
      }
    }

    // Check file name
    if (file.name.length > 100) {
      return {
        valid: false,
        error: 'File name too long. Maximum 100 characters.'
      }
    }

    return { valid: true }
  }

  static async uploadFile(file: File, userId: string): Promise<FileUploadResult> {
    try {
      // Validate file first
      const validation = this.validateFile(file)
      if (!validation.valid) {
        return {
          success: false,
          error: validation.error
        }
      }

      // Ensure bucket exists
      await this.ensureBucketExists()

      // Generate unique filename with user folder structure
      const fileExt = file.name.split('.').pop() || 'unknown'
      const timestamp = Date.now()
      const randomId = Math.random().toString(36).substring(2, 8)
      const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_')
      const fileName = `${userId}/${timestamp}-${randomId}-${sanitizedName}`

      // Upload file to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(this.BUCKET_NAME)
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
          contentType: file.type
        })

      if (uploadError) {
        console.error('Upload error:', uploadError)
        
        // If bucket doesn't exist, try to create it and retry
        if (uploadError.message.includes('Bucket not found')) {
          await this.ensureBucketExists()
          
          // Retry upload
          const { data: retryData, error: retryError } = await supabase.storage
            .from(this.BUCKET_NAME)
            .upload(fileName, file, {
              cacheControl: '3600',
              upsert: false,
              contentType: file.type
            })
            
          if (retryError) {
            return {
              success: false,
              error: `Upload failed after retry: ${retryError.message}`
            }
          }
        } else {
          return {
            success: false,
            error: `Upload failed: ${uploadError.message}`
          }
        }
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from(this.BUCKET_NAME)
        .getPublicUrl(fileName)

      if (!urlData?.publicUrl) {
        return {
          success: false,
          error: 'Failed to generate public URL'
        }
      }

      return {
        success: true,
        url: urlData.publicUrl,
        publicUrl: urlData.publicUrl,
        fileName: fileName
      }
    } catch (error) {
      console.error('File upload error:', error)
      return {
        success: false,
        error: `Upload failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  static async deleteFile(fileName: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase.storage
        .from(this.BUCKET_NAME)
        .remove([fileName])

      if (error) {
        return {
          success: false,
          error: `Delete failed: ${error.message}`
        }
      }

      return { success: true }
    } catch (error) {
      return {
        success: false,
        error: `Delete failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      }
    }
  }

  static async getFileUrl(fileName: string): Promise<string | null> {
    try {
      const { data } = supabase.storage
        .from(this.BUCKET_NAME)
        .getPublicUrl(fileName)

      return data?.publicUrl || null
    } catch (error) {
      console.error('Error getting file URL:', error)
      return null
    }
  }

  static formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  static getFileIcon(fileType: string): string {
    switch (fileType) {
      case 'application/pdf':
        return '📄'
      case 'application/json':
        return '📋'
      case 'text/csv':
        return '📊'
      case 'application/zip':
      case 'application/x-zip-compressed':
        return '🗜️'
      case 'application/vnd.ms-excel':
      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
        return '📈'
      case 'text/plain':
        return '📝'
      default:
        return '📎'
    }
  }

  static getFileTypeLabel(fileType: string): string {
    switch (fileType) {
      case 'application/pdf':
        return 'PDF Document'
      case 'application/json':
        return 'JSON Data'
      case 'text/csv':
        return 'CSV Spreadsheet'
      case 'application/zip':
      case 'application/x-zip-compressed':
        return 'ZIP Archive'
      case 'application/vnd.ms-excel':
        return 'Excel Spreadsheet (XLS)'
      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
        return 'Excel Spreadsheet (XLSX)'
      case 'text/plain':
        return 'Text Document'
      default:
        return 'Unknown File Type'
    }
  }
}
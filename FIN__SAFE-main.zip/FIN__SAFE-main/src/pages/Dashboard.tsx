import React, { useState, useEffect } from 'react'
import { Shield, Users, AlertTriangle, Activity, TrendingUp, Database, Clock, CheckCircle, FileText, Eye } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import { supabase, dbHelpers } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'

interface DashboardStats {
  totalShares: number
  activePartners: number
  riskAlerts: number
  complianceScore: number
  recentActivity: ActivityItem[]
  monthlyTrends: TrendData[]
  partnerActivity: PartnerData[]
  statusDistribution: StatusData[]
}

interface ActivityItem {
  id: string
  type: 'data_share' | 'permission' | 'audit' | 'compliance'
  title: string
  description: string
  timestamp: string
  status: 'success' | 'warning' | 'error'
}

interface TrendData {
  name: string
  shares: number
  access: number
  compliance: number
}

interface PartnerData {
  name: string
  shares: number
  lastAccess: string
  status: 'active' | 'inactive'
}

interface StatusData {
  name: string
  value: number
  color: string
}

const COLORS = ['#10B981', '#F59E0B', '#EF4444', '#6B7280']

export function Dashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalShares: 0,
    activePartners: 0,
    riskAlerts: 0,
    complianceScore: 98,
    recentActivity: [],
    monthlyTrends: [],
    partnerActivity: [],
    statusDistribution: []
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchDashboardData()
      // Create sample data if this is a new user
      createSampleDataIfNeeded()
    }
  }, [user])

  const createSampleDataIfNeeded = async () => {
    if (!user) return
    
    try {
      // Check if user already has data
      const existingShares = await dbHelpers.getDataShares(user.id)
      if (existingShares.length === 0) {
        // Create sample data for demo
        await dbHelpers.createSampleData(user.id)
        // Refresh dashboard after creating sample data
        setTimeout(() => fetchDashboardData(), 1000)
      }
    } catch (error) {
      console.error('Error creating sample data:', error)
    }
  }

  const fetchDashboardData = async () => {
    if (!user) return

    try {
      setLoading(true)

      // Fetch data using helper functions
      const [dataShares, auditLogsRes, permissionsRes] = await Promise.all([
        dbHelpers.getDataShares(user.id),
        supabase.from('audit_logs').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10),
        supabase.from('permissions').select('*').eq('user_id', user.id)
      ])

      const auditLogs = auditLogsRes.data || []
      const permissions = permissionsRes.data || []

      // Calculate unique partners
      const uniquePartners = new Set(dataShares.map(share => share.partner_name))

      // Calculate risk alerts (mock calculation)
      const riskAlerts = dataShares.filter(share => {
        const expiresAt = new Date(share.expires_at)
        const now = new Date()
        const daysUntilExpiry = Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
        return daysUntilExpiry <= 7 && daysUntilExpiry > 0
      }).length

      // Generate recent activity from audit logs and data shares
      const recentActivity: ActivityItem[] = [
        ...auditLogs.slice(0, 5).map(log => ({
          id: log.id,
          type: 'audit' as const,
          title: log.action.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          description: `${log.resource_type} - ${log.resource_id}`,
          timestamp: log.created_at,
          status: 'success' as const
        })),
        ...dataShares.slice(0, 3).map(share => ({
          id: share.id,
          type: 'data_share' as const,
          title: 'Data Share Created',
          description: `${share.partner_name} - ${share.data_type}`,
          timestamp: share.created_at,
          status: share.status === 'active' ? 'success' as const : 'warning' as const
        }))
      ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 6)

      // Generate monthly trends (mock data based on actual data)
      const monthlyTrends: TrendData[] = [
        { name: 'Jan', shares: Math.max(dataShares.length - 5, 0), access: auditLogs.length - 3, compliance: 95 },
        { name: 'Feb', shares: Math.max(dataShares.length - 3, 0), access: auditLogs.length - 2, compliance: 96 },
        { name: 'Mar', shares: Math.max(dataShares.length - 2, 0), access: auditLogs.length - 1, compliance: 97 },
        { name: 'Apr', shares: Math.max(dataShares.length - 1, 0), access: auditLogs.length, compliance: 98 },
        { name: 'May', shares: dataShares.length, access: auditLogs.length + 1, compliance: 98 },
        { name: 'Jun', shares: dataShares.length, access: auditLogs.length, compliance: 98 },
      ]

      // Generate partner activity
      const partnerCounts = dataShares.reduce((acc, share) => {
        acc[share.partner_name] = (acc[share.partner_name] || 0) + 1
        return acc
      }, {} as Record<string, number>)

      const partnerActivity: PartnerData[] = Object.entries(partnerCounts).map(([name, shares]) => ({
        name,
        shares,
        lastAccess: dataShares.find(s => s.partner_name === name)?.last_accessed || 'Never',
        status: Math.random() > 0.3 ? 'active' : 'inactive'
      }))

      // Generate status distribution
      const statusCounts = dataShares.reduce((acc, share) => {
        acc[share.status] = (acc[share.status] || 0) + 1
        return acc
      }, {} as Record<string, number>)

      const statusDistribution: StatusData[] = [
        { name: 'Active', value: statusCounts.active || 0, color: '#10B981' },
        { name: 'Pending', value: statusCounts.pending || 0, color: '#F59E0B' },
        { name: 'Revoked', value: statusCounts.revoked || 0, color: '#EF4444' },
      ].filter(item => item.value > 0)

      setStats({
        totalShares: dataShares.length,
        activePartners: uniquePartners.size,
        riskAlerts,
        complianceScore: 98, // Mock compliance score
        recentActivity,
        monthlyTrends,
        partnerActivity,
        statusDistribution
      })
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'data_share': return <Database className="h-4 w-4" />
      case 'permission': return <Shield className="h-4 w-4" />
      case 'audit': return <Eye className="h-4 w-4" />
      case 'compliance': return <FileText className="h-4 w-4" />
      default: return <Activity className="h-4 w-4" />
    }
  }

  const getActivityColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-600 bg-green-100'
      case 'warning': return 'text-yellow-600 bg-yellow-100'
      case 'error': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                <p className="mt-2 text-sm text-gray-600">
                  Monitor your data sharing activities and security metrics
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className="text-sm text-gray-500">Last updated</p>
                  <p className="text-sm font-medium text-gray-900">
                    {new Date().toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Database className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Data Shares</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalShares}</p>
                  <p className="text-xs text-green-600 mt-1">
                    <TrendingUp className="h-3 w-3 inline mr-1" />
                    +12% from last month
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Partners</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activePartners}</p>
                  <p className="text-xs text-green-600 mt-1">
                    <TrendingUp className="h-3 w-3 inline mr-1" />
                    +2 new this month
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Risk Alerts</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.riskAlerts}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Expiring soon
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Shield className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Compliance Score</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.complianceScore}%</p>
                  <p className="text-xs text-green-600 mt-1">
                    <CheckCircle className="h-3 w-3 inline mr-1" />
                    Excellent
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Trends Chart */}
            <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Activity Trends</h3>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                    <span className="text-gray-600">Data Shares</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-gray-600">Access Events</span>
                  </div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={stats.monthlyTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="shares" 
                    stroke="#3B82F6" 
                    strokeWidth={3}
                    dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="access" 
                    stroke="#10B981" 
                    strokeWidth={3}
                    dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Status Distribution */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Share Status</h3>
              {stats.statusDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={stats.statusDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stats.statusDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-48 text-gray-500">
                  No data available
                </div>
              )}
              <div className="mt-4 space-y-2">
                {stats.statusDistribution.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-2" 
                        style={{ backgroundColor: item.color }}
                      ></div>
                      <span className="text-sm text-gray-600">{item.name}</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Partner Activity & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Partner Activity */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Partner Activity</h3>
              {stats.partnerActivity.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={stats.partnerActivity}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="name" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }} 
                    />
                    <Bar dataKey="shares" fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-64 text-gray-500">
                  <div className="text-center">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                    <p>No partner activity yet</p>
                  </div>
                </div>
              )}
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
              <div className="space-y-4">
                {stats.recentActivity.length > 0 ? (
                  stats.recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${getActivityColor(activity.status)}`}>
                        {getActivityIcon(activity.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                        <p className="text-sm text-gray-500">{activity.description}</p>
                        <div className="flex items-center mt-1">
                          <Clock className="h-3 w-3 text-gray-400 mr-1" />
                          <span className="text-xs text-gray-400">
                            {new Date(activity.timestamp).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center justify-center h-48 text-gray-500">
                    <div className="text-center">
                      <Activity className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                      <p>No recent activity</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <button className="p-4 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 text-center">
                <Database className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-900">Create Data Share</p>
              </button>
              <button className="p-4 border-2 border-dashed border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all duration-200 text-center">
                <Shield className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-900">Manage Permissions</p>
              </button>
              <button className="p-4 border-2 border-dashed border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-all duration-200 text-center">
                <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-900">Generate Report</p>
              </button>
              <button className="p-4 border-2 border-dashed border-gray-200 rounded-lg hover:border-yellow-300 hover:bg-yellow-50 transition-all duration-200 text-center">
                <Eye className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-900">View Audit Logs</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
import React, { useState } from 'react'
import { Shield, Database, Users, Eye, Lock, FileCheck, Bell, TrendingUp, CheckCircle, ArrowRight, Play, Pause, RotateCcw } from 'lucide-react'

interface DemoStep {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  details: string[]
  visual: React.ReactNode
}

export function Demo() {
  const [activeStep, setActiveStep] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentFeature, setCurrentFeature] = useState(0)

  const demoSteps: DemoStep[] = [
    {
      id: 'overview',
      title: 'Welcome to finSafe',
      description: 'The most secure way to share financial data between institutions',
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      details: [
        'Enterprise-grade security for financial data sharing',
        'Compliance with GDPR, DPDP Act, and SOC 2 standards',
        'Real-time monitoring and audit trails',
        'User-controlled permissions and consent management'
      ],
      visual: (
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-xl">
          <div className="flex items-center justify-center space-x-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-3">
                <Database className="h-8 w-8 text-white" />
              </div>
              <p className="text-sm font-medium">Your Bank</p>
            </div>
            <div className="flex-1 flex items-center justify-center">
              <div className="w-full h-2 bg-blue-200 rounded-full relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-green-600 rounded-full animate-pulse"></div>
              </div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mb-3">
                <Users className="h-8 w-8 text-white" />
              </div>
              <p className="text-sm font-medium">Partner</p>
            </div>
          </div>
          <p className="text-center text-gray-600 mt-6">Secure, encrypted data sharing with full audit trails</p>
        </div>
      )
    },
    {
      id: 'data-sharing',
      title: 'Smart Data Sharing',
      description: 'Create secure data shares with partners using advanced tokenization',
      icon: <Database className="h-8 w-8 text-green-600" />,
      details: [
        'Upload files or enter data manually',
        'Set expiration dates and access controls',
        'Dynamic tokenization replaces sensitive data',
        'Smart contracts embed usage policies'
      ],
      visual: (
        <div className="bg-white p-6 rounded-xl border-2 border-gray-200">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center space-x-3">
                <FileCheck className="h-6 w-6 text-green-600" />
                <div>
                  <p className="font-medium text-green-900">Transaction Data</p>
                  <p className="text-sm text-green-700">Shared with Credit Union</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">Active</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-3">
                <FileCheck className="h-6 w-6 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-900">Credit Score</p>
                  <p className="text-sm text-blue-700">Shared with Fintech Co</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">Pending</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center space-x-3">
                <FileCheck className="h-6 w-6 text-gray-600" />
                <div>
                  <p className="font-medium text-gray-900">Account Balance</p>
                  <p className="text-sm text-gray-700">Shared with Insurance Corp</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">Revoked</span>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'permissions',
      title: 'Granular Permissions',
      description: 'Control exactly what data each partner can access',
      icon: <Lock className="h-8 w-8 text-purple-600" />,
      details: [
        'Matrix-based permission control',
        'Data type specific access rights',
        'Real-time permission updates',
        'Automatic expiration and revocation'
      ],
      visual: (
        <div className="bg-white p-6 rounded-xl border-2 border-gray-200">
          <div className="grid grid-cols-4 gap-2 text-xs">
            <div className="font-medium p-2">Data Type</div>
            <div className="font-medium p-2 text-center">Bank A</div>
            <div className="font-medium p-2 text-center">Credit Union</div>
            <div className="font-medium p-2 text-center">Fintech Co</div>
            
            <div className="p-2 text-gray-700">Account Balance</div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
            <div className="p-2 text-center"><div className="h-4 w-4 bg-gray-300 rounded-full mx-auto"></div></div>
            
            <div className="p-2 text-gray-700">Transaction History</div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
            <div className="p-2 text-center"><div className="h-4 w-4 bg-gray-300 rounded-full mx-auto"></div></div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
            
            <div className="p-2 text-gray-700">Credit Score</div>
            <div className="p-2 text-center"><div className="h-4 w-4 bg-gray-300 rounded-full mx-auto"></div></div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
            <div className="p-2 text-center"><CheckCircle className="h-4 w-4 text-green-500 mx-auto" /></div>
          </div>
        </div>
      )
    },
    {
      id: 'monitoring',
      title: 'Real-Time Monitoring',
      description: 'Track all data access with comprehensive audit logs',
      icon: <Eye className="h-8 w-8 text-orange-600" />,
      details: [
        'Real-time access monitoring',
        'Comprehensive audit trails',
        'Anomaly detection and alerts',
        'Compliance reporting automation'
      ],
      visual: (
        <div className="bg-white p-6 rounded-xl border-2 border-gray-200">
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-green-900">Data Access - Credit Union</p>
                <p className="text-xs text-green-700">Transaction history accessed • 2 min ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-900">Permission Granted - Fintech Co</p>
                <p className="text-xs text-blue-700">Credit score access enabled • 5 min ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-yellow-900">Data Share Created - Bank A</p>
                <p className="text-xs text-yellow-700">Account balance sharing initiated • 10 min ago</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'compliance',
      title: 'Compliance & Reporting',
      description: 'Automated compliance monitoring and regulatory reporting',
      icon: <FileCheck className="h-8 w-8 text-red-600" />,
      details: [
        'GDPR, DPDP Act, SOC 2 compliance',
        'Automated compliance scoring',
        'One-click regulatory reports',
        'Risk assessment and alerts'
      ],
      visual: (
        <div className="bg-white p-6 rounded-xl border-2 border-gray-200">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-1">98%</div>
              <div className="text-sm text-green-700">Compliance Score</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-1">3</div>
              <div className="text-sm text-blue-700">Reports Generated</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600 mb-1">2</div>
              <div className="text-sm text-yellow-700">Active Issues</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-1">156</div>
              <div className="text-sm text-purple-700">Audit Events</div>
            </div>
          </div>
        </div>
      )
    }
  ]

  const features = [
    {
      title: 'Dynamic Tokenization',
      description: 'Replace sensitive data with secure tokens while preserving format and functionality',
      icon: <Lock className="h-6 w-6 text-blue-600" />,
      color: 'blue'
    },
    {
      title: 'Smart Contracts',
      description: 'Embed usage policies directly into data with automated enforcement',
      icon: <FileCheck className="h-6 w-6 text-green-600" />,
      color: 'green'
    },
    {
      title: 'Real-Time Monitoring',
      description: 'Monitor data access patterns and detect anomalies instantly',
      icon: <Eye className="h-6 w-6 text-purple-600" />,
      color: 'purple'
    },
    {
      title: 'User Consent Control',
      description: 'Give customers full control over their data sharing preferences',
      icon: <Users className="h-6 w-6 text-orange-600" />,
      color: 'orange'
    },
    {
      title: 'Compliance Ready',
      description: 'Automated reporting for GDPR, DPDP Act, and other regulations',
      icon: <Shield className="h-6 w-6 text-red-600" />,
      color: 'red'
    },
    {
      title: 'API Integration',
      description: 'Seamlessly integrate with existing fintech infrastructure',
      icon: <TrendingUp className="h-6 w-6 text-indigo-600" />,
      color: 'indigo'
    }
  ]

  const startDemo = () => {
    setIsPlaying(true)
    const interval = setInterval(() => {
      setActiveStep(prev => {
        if (prev >= demoSteps.length - 1) {
          setIsPlaying(false)
          clearInterval(interval)
          return prev
        }
        return prev + 1
      })
    }, 4000)
  }

  const resetDemo = () => {
    setActiveStep(0)
    setIsPlaying(false)
  }

  const pauseDemo = () => {
    setIsPlaying(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <Shield className="h-16 w-16 text-blue-600" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            finSafe Interactive Demo
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Discover how finSafe revolutionizes secure financial data sharing with 
            enterprise-grade security, compliance automation, and real-time monitoring.
          </p>
          
          {/* Demo Controls */}
          <div className="flex justify-center space-x-4 mb-12">
            <button
              onClick={startDemo}
              disabled={isPlaying}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2 transition-all"
            >
              <Play className="h-5 w-5" />
              {isPlaying ? 'Demo Running...' : 'Start Interactive Demo'}
            </button>
            <button
              onClick={pauseDemo}
              disabled={!isPlaying}
              className="bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 disabled:opacity-50 flex items-center gap-2 transition-all"
            >
              <Pause className="h-5 w-5" />
              Pause
            </button>
            <button
              onClick={resetDemo}
              className="bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-700 flex items-center gap-2 transition-all"
            >
              <RotateCcw className="h-5 w-5" />
              Reset
            </button>
          </div>
        </div>

        {/* Interactive Demo Steps */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden mb-16">
          {/* Step Navigation */}
          <div className="bg-gray-50 px-6 py-4 border-b">
            <div className="flex space-x-1 overflow-x-auto">
              {demoSteps.map((step, index) => (
                <button
                  key={step.id}
                  onClick={() => setActiveStep(index)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                    activeStep === index
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {step.icon}
                  <span>{step.title}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <div className="p-8">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center space-x-3 mb-4">
                  {demoSteps[activeStep].icon}
                  <h2 className="text-2xl font-bold text-gray-900">
                    {demoSteps[activeStep].title}
                  </h2>
                </div>
                <p className="text-lg text-gray-600 mb-6">
                  {demoSteps[activeStep].description}
                </p>
                <ul className="space-y-3">
                  {demoSteps[activeStep].details.map((detail, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="lg:pl-8">
                {demoSteps[activeStep].visual}
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="bg-gray-100 h-2">
            <div
              className="bg-blue-600 h-2 transition-all duration-500 ease-out"
              style={{ width: `${((activeStep + 1) / demoSteps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Key Features Grid */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Enterprise-Grade Security Features
            </h2>
            <p className="text-xl text-gray-600">
              Comprehensive data protection with advanced privacy controls
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1 ${
                  currentFeature === index ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setCurrentFeature(index)}
              >
                <div className={`w-12 h-12 bg-${feature.color}-100 rounded-lg flex items-center justify-center mb-4`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* How It Works Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How finSafe Works
            </h2>
            <p className="text-xl text-gray-600">
              Simple, secure, and compliant data sharing in 4 easy steps
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: '1',
                title: 'Create Data Share',
                description: 'Upload files or enter data manually with expiration dates and access controls',
                icon: <Database className="h-8 w-8 text-blue-600" />
              },
              {
                step: '2',
                title: 'Set Permissions',
                description: 'Define granular permissions for each partner and data type',
                icon: <Lock className="h-8 w-8 text-green-600" />
              },
              {
                step: '3',
                title: 'Monitor Access',
                description: 'Real-time monitoring with comprehensive audit trails and alerts',
                icon: <Eye className="h-8 w-8 text-purple-600" />
              },
              {
                step: '4',
                title: 'Generate Reports',
                description: 'Automated compliance reports for GDPR, DPDP Act, and SOC 2',
                icon: <FileCheck className="h-8 w-8 text-red-600" />
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    {item.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {item.step}
                  </div>
                  {index < 3 && (
                    <ArrowRight className="hidden md:block absolute top-6 -right-12 h-6 w-6 text-gray-400" />
                  )}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 text-sm">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits Section */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl text-white p-8 mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">
              Why Choose finSafe?
            </h2>
            <p className="text-xl opacity-90">
              The most trusted platform for secure financial data sharing
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: '99.9% Uptime',
                description: 'Enterprise-grade reliability with 24/7 monitoring',
                icon: <TrendingUp className="h-8 w-8" />
              },
              {
                title: 'SOC 2 Compliant',
                description: 'Certified security controls for financial institutions',
                icon: <Shield className="h-8 w-8" />
              },
              {
                title: '< 100ms Response',
                description: 'Lightning-fast API responses for real-time operations',
                icon: <Bell className="h-8 w-8" />
              }
            ].map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">
                  {benefit.title}
                </h3>
                <p className="opacity-90">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Secure Your Data Sharing?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join leading fintech companies using finSafe to protect customer data.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/register"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Start Your Free Trial
            </a>
            <a
              href="/login"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold border border-blue-600 hover:bg-blue-50 transition-colors"
            >
              Sign In
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
import React, { useState, useEffect } from 'react'
import { Shield, Settings, Bell, CheckCircle, AlertTriangle } from 'lucide-react'
import { supabase, dbHelpers } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'

interface Permission {
  id: string
  partner_id: string
  data_type: string
  granted: boolean
  created_at: string
  updated_at: string
}

const dataTypes = [
  { id: 'account_balance', name: 'Account Balance', description: 'Current account balance information' },
  { id: 'transaction_history', name: 'Transaction History', description: 'Historical transaction records' },
  { id: 'personal_info', name: 'Personal Information', description: 'Name, address, and contact details' },
  { id: 'credit_score', name: 'Credit Score', description: 'Credit rating and history' },
  { id: 'investment_portfolio', name: 'Investment Portfolio', description: 'Investment holdings and performance' },
  { id: 'loan_details', name: 'Loan Details', description: 'Loan amounts, terms, and payment history' },
  { id: 'payment_history', name: 'Payment History', description: 'Historical payment records and patterns' },
  { id: 'kyc_documents', name: 'KYC Documents', description: 'Know Your Customer verification documents' },
]

const partners = [
  { id: 'bank_a', name: 'Bank A', description: 'Primary banking partner' },
  { id: 'credit_union', name: 'Credit Union', description: 'Community financial institution' },
  { id: 'fintech_co', name: 'Fintech Co', description: 'Digital financial services' },
  { id: 'insurance_corp', name: 'Insurance Corp', description: 'Insurance and risk management' },
]

export function Permissions() {
  const { user } = useAuth()
  const [permissions, setPermissions] = useState<Permission[]>([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState<string | null>(null)
  const [globalSettings, setGlobalSettings] = useState({
    emailNotifications: true,
    autoRevoke: false
  })

  useEffect(() => {
    if (user) {
      fetchPermissions()
    }
  }, [user])

  const fetchPermissions = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('permissions')
        .select('*')
        .eq('user_id', user.id)

      if (error) throw error
      setPermissions(data || [])
    } catch (error) {
      console.error('Error fetching permissions:', error)
    } finally {
      setLoading(false)
    }
  }

  const togglePermission = async (partnerId: string, dataType: string, currentStatus: boolean) => {
    if (!user) return

    const permissionKey = `${partnerId}-${dataType}`
    setUpdating(permissionKey)

    try {
      const updatedPermission = await dbHelpers.updatePermission(
        user.id,
        partnerId,
        dataType,
        !currentStatus
      )

      // Log the permission change
      await dbHelpers.logAuditEvent(
        user.id,
        !currentStatus ? 'permission_granted' : 'permission_revoked',
        'permission',
        updatedPermission.id,
        {
          partner_id: partnerId,
          data_type: dataType,
          previous_status: currentStatus,
          new_status: !currentStatus
        }
      )

      // Refresh permissions
      await fetchPermissions()
    } catch (error) {
      console.error('Error updating permission:', error)
      alert('Failed to update permission. Please try again.')
    } finally {
      setUpdating(null)
    }
  }

  const toggleGlobalSetting = async (setting: 'emailNotifications' | 'autoRevoke') => {
    if (!user) return
    
    const newValue = !globalSettings[setting]
    setGlobalSettings(prev => ({ ...prev, [setting]: newValue }))

    // Log the global setting change
    await dbHelpers.logAuditEvent(
      user.id,
      'settings_updated',
      'global_settings',
      setting,
      {
        setting_name: setting,
        previous_value: globalSettings[setting],
        new_value: newValue
      }
    )
  }

  const getPermissionStatus = (partnerId: string, dataType: string) => {
    const permission = permissions.find(
      p => p.partner_id === partnerId && p.data_type === dataType
    )
    return permission?.granted || false
  }

  const getPermissionCount = (partnerId: string) => {
    return permissions.filter(p => p.partner_id === partnerId && p.granted).length
  }

  const getTotalGrantedPermissions = () => {
    return permissions.filter(p => p.granted).length
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Data Permissions</h1>
            <p className="mt-2 text-sm text-gray-600">
              Control which partners can access your financial data
            </p>
            <div className="mt-4 flex items-center space-x-4 text-sm text-gray-500">
              <span>Total Permissions: {getTotalGrantedPermissions()}</span>
              <span>•</span>
              <span>Partners: {partners.length}</span>
              <span>•</span>
              <span>Data Types: {dataTypes.length}</span>
            </div>
          </div>

          {/* Global Settings */}
          <div className="bg-white rounded-lg shadow mb-6">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Global Settings</h3>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Bell className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Email Notifications</p>
                    <p className="text-sm text-gray-500">Get notified when partners access your data</p>
                  </div>
                </div>
                <button
                  onClick={() => toggleGlobalSetting('emailNotifications')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    globalSettings.emailNotifications ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      globalSettings.emailNotifications ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Settings className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Auto-Revoke</p>
                    <p className="text-sm text-gray-500">Automatically revoke access after 90 days of inactivity</p>
                  </div>
                </div>
                <button
                  onClick={() => toggleGlobalSetting('autoRevoke')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    globalSettings.autoRevoke ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      globalSettings.autoRevoke ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Permission Matrix */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Data Access Permissions</h3>
              <p className="text-sm text-gray-500 mt-1">
                Grant or revoke access to specific data types for each partner
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Data Type
                    </th>
                    {partners.map(partner => (
                      <th key={partner.id} className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {partner.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {dataTypes.map(dataType => (
                    <tr key={dataType.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{dataType.name}</div>
                          <div className="text-sm text-gray-500">{dataType.description}</div>
                        </div>
                      </td>
                      {partners.map(partner => {
                        const isGranted = getPermissionStatus(partner.id, dataType.id)
                        const isUpdating = updating === `${partner.id}-${dataType.id}`
                        
                        return (
                          <td key={partner.id} className="px-6 py-4 whitespace-nowrap text-center">
                            <button
                              onClick={() => togglePermission(partner.id, dataType.id, isGranted)}
                              disabled={isUpdating}
                              className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                                isGranted
                                  ? 'bg-green-100 text-green-800 hover:bg-green-200'
                                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                              } ${isUpdating ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                            >
                              {isUpdating ? (
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-1"></div>
                              ) : isGranted ? (
                                <CheckCircle className="h-4 w-4 mr-1" />
                              ) : (
                                <AlertTriangle className="h-4 w-4 mr-1" />
                              )}
                              {isGranted ? 'Granted' : 'Denied'}
                            </button>
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Partner Information */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {partners.map(partner => (
              <div key={partner.id} className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center mb-2">
                  <Shield className="h-5 w-5 text-blue-600 mr-2" />
                  <h4 className="text-sm font-medium text-gray-900">{partner.name}</h4>
                </div>
                <p className="text-sm text-gray-500 mb-3">{partner.description}</p>
                <div className="flex items-center justify-between">
                  <div className="text-xs text-gray-400">
                    {getPermissionCount(partner.id)} of {dataTypes.length} permissions
                  </div>
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(getPermissionCount(partner.id) / dataTypes.length) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
import React, { useState, useEffect } from 'react'
import { Plus, Search, Filter, Shield, Clock, X, Upload, FileText, AlertCircle, CheckCircle, Info } from 'lucide-react'
import { supabase, dbHelpers } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { StorageService } from '../lib/storage'

interface DataShare {
  id: string
  partner_name: string
  data_type: string
  purpose: string
  status: 'active' | 'revoked' | 'pending'
  created_at: string
  expires_at: string
  last_accessed: string
  details?: Record<string, any>
}

interface UploadedFile {
  name: string
  size: number
  type: string
  url?: string
  fileName?: string
  uploading?: boolean
  error?: string
}

interface NewShareForm {
  partner_name: string
  data_type: string
  purpose: string
  expires_at: string
  uploaded_files: UploadedFile[]
  upload_method: 'manual' | 'file'
}

export function DataSharing() {
  const { user } = useAuth()
  const [dataShares, setDataShares] = useState<DataShare[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [createLoading, setCreateLoading] = useState(false)
  const [storageWarning, setStorageWarning] = useState<string | null>(null)
  const [newShare, setNewShare] = useState<NewShareForm>({
    partner_name: '',
    data_type: '',
    purpose: '',
    expires_at: '',
    uploaded_files: [],
    upload_method: 'manual'
  })

  const dataTypes = [
    'Account Balance',
    'Transaction History',
    'Personal Information',
    'Credit Score',
    'Investment Portfolio',
    'Loan Details',
    'Payment History',
    'KYC Documents'
  ]

  useEffect(() => {
    if (user) {
      fetchDataShares()
      checkStorageSetup()
    }
  }, [user])

  const checkStorageSetup = async () => {
    const validation = await StorageService.validateStorageSetup()
    if (!validation.isValid && validation.error) {
      setStorageWarning(validation.error)
    } else {
      setStorageWarning(null)
    }
  }

  const fetchDataShares = async () => {
    if (!user) return

    try {
      const data = await dbHelpers.getDataShares(user.id)
      setDataShares(data)
    } catch (error) {
      console.error('Error fetching data shares:', error)
      setDataShares([])
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async (files: FileList) => {
    if (!user) return

    for (const file of Array.from(files)) {
      // Validate file
      const validation = StorageService.validateFile(file)
      if (!validation.valid) {
        alert(`File validation error for ${file.name}: ${validation.error}`)
        continue
      }

      // Add file to state with uploading status
      const uploadingFile: UploadedFile = {
        name: file.name,
        size: file.size,
        type: file.type,
        uploading: true
      }

      setNewShare(prev => ({
        ...prev,
        uploaded_files: [...prev.uploaded_files, uploadingFile]
      }))

      try {
        // Upload file
        const result = await StorageService.uploadFile(file, user.id)
        
        if (result.success) {
          // Update file with success
          setNewShare(prev => ({
            ...prev,
            uploaded_files: prev.uploaded_files.map(f => 
              f.name === file.name && f.uploading
                ? { ...f, uploading: false, url: result.url, fileName: result.fileName }
                : f
            )
          }))

          // Log file upload
          try {
            await dbHelpers.logAuditEvent(
              user.id,
              'file_uploaded',
              'data_share_file',
              result.fileName || file.name,
              {
                file_name: file.name,
                file_size: file.size,
                file_type: file.type,
                upload_timestamp: new Date().toISOString()
              }
            )
          } catch (auditError) {
            console.error('Error logging file upload:', auditError)
          }
        } else {
          throw new Error(result.error || 'Upload failed')
        }
      } catch (error) {
        console.error(`Error uploading ${file.name}:`, error)
        
        // Update file with error
        setNewShare(prev => ({
          ...prev,
          uploaded_files: prev.uploaded_files.map(f => 
            f.name === file.name && f.uploading
              ? { ...f, uploading: false, error: error instanceof Error ? error.message : 'Upload failed' }
              : f
          )
        }))
      }
    }
  }

  const removeFile = async (fileName: string) => {
    const fileToRemove = newShare.uploaded_files.find(f => f.name === fileName)
    
    // If file was uploaded, delete it from storage
    if (fileToRemove?.fileName) {
      try {
        await StorageService.deleteFile(fileToRemove.fileName)
      } catch (error) {
        console.error('Error deleting file:', error)
      }
    }

    setNewShare(prev => ({
      ...prev,
      uploaded_files: prev.uploaded_files.filter(f => f.name !== fileName)
    }))
  }

  const handleCreateShare = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    try {
      setCreateLoading(true)
      
      // Validate form based on upload method
      if (newShare.upload_method === 'file') {
        if (newShare.uploaded_files.length === 0) {
          alert('Please upload at least one file or switch to manual entry.')
          return
        }
        
        if (newShare.uploaded_files.some(f => f.uploading)) {
          alert('Please wait for all files to finish uploading.')
          return
        }
        
        const filesWithErrors = newShare.uploaded_files.filter(f => f.error)
        if (filesWithErrors.length > 0) {
          alert(`Please remove files with errors before proceeding.`)
          return
        }
      }
      
      // Prepare file metadata for successful uploads
      const successfulFiles = newShare.uploaded_files.filter(f => f.url && f.fileName && !f.error)
      
      const data = await dbHelpers.createDataShare({
        user_id: user.id,
        partner_name: newShare.partner_name,
        data_type: newShare.data_type,
        purpose: newShare.purpose,
        expires_at: newShare.expires_at,
        status: 'pending' as const,
        details: {
          files: successfulFiles.map(f => ({
            name: f.name,
            size: f.size,
            type: f.type,
            url: f.url,
            fileName: f.fileName
          })),
          upload_method: newShare.upload_method,
          created_via: 'web_interface',
          files_count: successfulFiles.length
        }
      })

      // Log the data share creation
      try {
        await dbHelpers.logAuditEvent(
          user.id,
          'data_share_created',
          'data_share',
          data.id,
          {
            partner_name: newShare.partner_name,
            data_type: newShare.data_type,
            upload_method: newShare.upload_method,
            files_count: successfulFiles.length
          }
        )
      } catch (auditError) {
        console.error('Error logging data share creation:', auditError)
      }

      // Reset form and close modal
      setNewShare({
        partner_name: '',
        data_type: '',
        purpose: '',
        expires_at: '',
        uploaded_files: [],
        upload_method: 'manual'
      })
      setShowCreateModal(false)
      
      // Refresh data shares
      fetchDataShares()
      
      alert(`Data share created successfully${successfulFiles.length > 0 ? ` with ${successfulFiles.length} file(s)` : ''}!`)
      
    } catch (error) {
      console.error('Error creating data share:', error)
      alert(`Failed to create data share: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setCreateLoading(false)
    }
  }

  const handleRevokeAccess = async (id: string) => {
    try {
      const { error } = await supabase
        .from('data_shares')
        .update({ status: 'revoked' })
        .eq('id', id)

      if (error) throw error
      
      // Log the revocation
      if (user) {
        await dbHelpers.logAuditEvent(
          user.id,
          'data_share_revoked',
          'data_share',
          id
        )
      }
      
      fetchDataShares()
    } catch (error) {
      console.error('Error revoking access:', error)
      alert('Failed to revoke access. Please try again.')
    }
  }

  const filteredShares = dataShares.filter(share => {
    const matchesSearch = share.partner_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         share.data_type.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === 'all' || share.status === filterStatus
    return matchesSearch && matchesFilter
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'revoked': return 'bg-red-100 text-red-800'
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="mb-8">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Data Sharing</h1>
                <p className="mt-2 text-sm text-gray-600">
                  Manage your data sharing agreements and access controls
                </p>
              </div>
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                New Share
              </button>
            </div>
          </div>

          {/* Storage Setup Warning */}
          {storageWarning && (
            <div className="mb-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start">
                <Info className="h-5 w-5 text-yellow-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-yellow-800">Storage Setup Notice</h3>
                  <p className="text-sm text-yellow-700 mt-1">
                    {storageWarning}
                  </p>
                  <button
                    onClick={checkStorageSetup}
                    className="mt-2 text-sm text-yellow-800 underline hover:text-yellow-900"
                  >
                    Retry setup check
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Search and Filter */}
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search partners or data types..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="revoked">Revoked</option>
            </select>
          </div>

          {/* Data Shares Table */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Partner
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Purpose
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Files
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Expires
                  </th>
                  <th className="relative px-6 py-3">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredShares.map((share) => (
                  <tr key={share.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Shield className="h-5 w-5 text-gray-400 mr-3" />
                        <div className="text-sm font-medium text-gray-900">{share.partner_name}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {share.data_type}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {share.purpose}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(share.status)}`}>
                        {share.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {share.details?.files?.length ? (
                        <div className="flex items-center">
                          <FileText className="h-4 w-4 text-gray-400 mr-1" />
                          <span>{share.details.files.length} file(s)</span>
                        </div>
                      ) : (
                        <span className="text-gray-400">Manual entry</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-gray-400 mr-2" />
                        {new Date(share.expires_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleRevokeAccess(share.id)}
                        disabled={share.status === 'revoked'}
                        className="text-red-600 hover:text-red-900 disabled:text-gray-400"
                      >
                        {share.status === 'revoked' ? 'Revoked' : 'Revoke'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredShares.length === 0 && (
              <div className="px-6 py-8 text-center">
                <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No data shares found</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create New Share Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Create New Data Share</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleCreateShare} className="space-y-4">
              {/* Upload Method Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data Entry Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setNewShare({ ...newShare, upload_method: 'manual', uploaded_files: [] })}
                    className={`p-3 border-2 rounded-lg text-left transition-all ${
                      newShare.upload_method === 'manual'
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-sm">Manual Entry</div>
                    <div className="text-xs text-gray-500 mt-1">Fill form manually</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewShare({ ...newShare, upload_method: 'file' })}
                    className={`p-3 border-2 rounded-lg text-left transition-all ${
                      newShare.upload_method === 'file'
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-sm">📎 File Upload</div>
                    <div className="text-xs text-gray-500 mt-1">
                      Upload files directly
                    </div>
                  </button>
                </div>
                {storageWarning && newShare.upload_method === 'file' && (
                  <div className="mt-2 text-xs text-red-600">
                    Note: {storageWarning}
                  </div>
                )}
              </div>

              {/* File Upload Section */}
              {newShare.upload_method === 'file' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Upload Files
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                    <input
                      type="file"
                      multiple
                      accept=".pdf,.json,.csv,.zip,.txt"
                      onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
                      className="hidden"
                      id="file-upload"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600 mb-1">
                        Click to upload or drag and drop
                      </p>
                      <p className="text-xs text-gray-500">
                        PDF, JSON, CSV, ZIP, TXT (max 10MB each)
                      </p>
                    </label>
                  </div>

                  {/* Uploaded Files List */}
                  {newShare.uploaded_files.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <h4 className="text-sm font-medium text-gray-700">Uploaded Files:</h4>
                      {newShare.uploaded_files.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <span className="text-lg">{StorageService.getFileIcon(file.type)}</span>
                            <div>
                              <p className="text-sm font-medium text-gray-900">{file.name}</p>
                              <p className="text-xs text-gray-500">{StorageService.formatFileSize(file.size)}</p>
                              {file.error && (
                                <p className="text-xs text-red-500 mt-1">{file.error}</p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {file.uploading && (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                                <span className="text-xs text-blue-600">Uploading...</span>
                              </>
                            )}
                            {file.error && (
                              <>
                                <AlertCircle className="h-4 w-4 text-red-500" />
                                <span className="text-xs text-red-500">Failed</span>
                              </>
                            )}
                            {file.url && !file.uploading && !file.error && (
                              <>
                                <CheckCircle className="h-4 w-4 text-green-500" />
                                <span className="text-xs text-green-600">Uploaded</span>
                              </>
                            )}
                            <button
                              type="button"
                              onClick={() => removeFile(file.name)}
                              className="text-red-500 hover:text-red-700"
                              title="Remove file"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Partner Name
                </label>
                <input
                  type="text"
                  required
                  value={newShare.partner_name}
                  onChange={(e) => setNewShare({ ...newShare, partner_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter partner name"
                />
              </div>

              {newShare.upload_method === 'manual' && (
                <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data Type
                </label>
                <select
                  required
                  value={newShare.data_type}
                  onChange={(e) => setNewShare({ ...newShare, data_type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select data type</option>
                  {dataTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                </div>
              )}

              {newShare.upload_method === 'file' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data Type
                  </label>
                  <input
                    type="text"
                    required
                    value={newShare.data_type}
                    onChange={(e) => setNewShare({ ...newShare, data_type: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter data type (e.g., Financial Reports, Transaction Data)"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Purpose
                </label>
                <textarea
                  required
                  value={newShare.purpose}
                  onChange={(e) => setNewShare({ ...newShare, purpose: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Describe the purpose of data sharing"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Expiration Date
                </label>
                <input
                  type="date"
                  required
                  value={newShare.expires_at}
                  onChange={(e) => setNewShare({ ...newShare, expires_at: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createLoading}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {createLoading ? 'Creating...' : 'Create Share'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
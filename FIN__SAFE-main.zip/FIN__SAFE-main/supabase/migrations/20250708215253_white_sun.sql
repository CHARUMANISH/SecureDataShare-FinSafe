/*
  # Storage Bucket Setup for Data Shares
  
  This migration provides instructions for setting up the storage bucket manually
  since storage buckets cannot be created via SQL migrations in Supabase.
  
  REQUIRED MANUAL STEPS:
  
  1. Go to Supabase Dashboard → Storage
  2. Click "Create Bucket"
  3. Configure the bucket with these exact settings:
     - Bucket Name: data-shares
     - Public: ✓ (checked)
     - File size limit: 50MB
     - Allowed MIME types: application/pdf,application/json,text/csv,application/zip,text/plain
  
  4. After creating the bucket, add these RLS policies:
  
  POLICY 1: "Users can upload files to own folder"
  - Operation: INSERT
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  POLICY 2: "Users can view own files"  
  - Operation: SELECT
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  POLICY 3: "Users can delete own files"
  - Operation: DELETE  
  - Target roles: authenticated
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
  
  POLICY 4: "Users can update own files"
  - Operation: UPDATE
  - Target roles: authenticated  
  - Policy definition:
    bucket_id = 'data-shares' AND (storage.foldername(name))[1] = auth.uid()::text
*/

-- Ensure the data_shares table has all required columns
DO $$
BEGIN
  -- Add details column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'details'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN details jsonb DEFAULT '{}';
  END IF;
  
  -- Ensure last_accessed column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'last_accessed'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN last_accessed timestamptz DEFAULT now();
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_data_shares_details ON data_shares USING gin (details);

-- Update existing records to have empty details object
UPDATE data_shares SET details = '{}' WHERE details IS NULL;

-- Create a helper function to check if storage is properly configured
CREATE OR REPLACE FUNCTION check_storage_setup()
RETURNS TABLE(
  bucket_exists boolean,
  setup_message text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    false as bucket_exists,
    'Storage bucket must be created manually in Supabase Dashboard. See migration comments for instructions.' as setup_message;
END;
$$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION check_storage_setup() TO authenticated;
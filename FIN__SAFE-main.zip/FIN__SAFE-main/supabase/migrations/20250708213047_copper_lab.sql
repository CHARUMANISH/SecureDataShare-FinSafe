/*
  # Update Data Shares Table for File Support

  1. Schema Changes
    - Add details column to store file information and metadata
    - Update existing records to have empty details object

  2. Indexes
    - Add index on details column for better query performance
*/

-- Add details column to data_shares table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'data_shares' AND column_name = 'details'
  ) THEN
    ALTER TABLE data_shares ADD COLUMN details jsonb DEFAULT '{}';
  END IF;
END $$;

-- Create index on details column for better performance
CREATE INDEX IF NOT EXISTS idx_data_shares_details ON data_shares USING gin(details);

-- Update existing records to have empty details object
UPDATE data_shares SET details = '{}' WHERE details IS NULL;
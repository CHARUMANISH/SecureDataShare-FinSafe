/*
  # Add Storage Bucket for Data Shares

  1. Storage Setup
    - Create 'data-shares' bucket for file uploads
    - Set up RLS policies for secure file access
    - Configure bucket settings for file types and size limits

  2. Security
    - Users can only upload files to their own folder
    - Users can only access their own files
    - Public access is controlled through RLS
*/

-- Create storage bucket for data share files
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'data-shares',
  'data-shares',
  true,
  10485760, -- 10MB limit
  ARRAY['application/pdf', 'application/json', 'text/csv', 'application/zip', 'application/x-zip-compressed']
) ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy: Users can upload files to their own folder
CREATE POLICY "Users can upload files to own folder"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'data-shares' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Users can view their own files
CREATE POLICY "Users can view own files"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'data-shares' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Users can delete their own files
CREATE POLICY "Users can delete own files"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'data-shares' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy: Users can update their own files
CREATE POLICY "Users can update own files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'data-shares' AND
  (storage.foldername(name))[1] = auth.uid()::text
);
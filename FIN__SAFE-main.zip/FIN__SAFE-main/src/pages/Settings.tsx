import React, { useState } from 'react'
import { User, Bell, Shield, Key, Globe, Save } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { dbHelpers } from '../lib/supabase'

export function Settings() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('profile')
  const [settings, setSettings] = useState({
    profile: {
      companyName: '',
      contactEmail: user?.email || '',
      phone: '',
      industry: 'fintech',
      timezone: 'UTC'
    },
    notifications: {
      emailAlerts: true,
      dataAccessNotifications: true,
      complianceReports: true,
      securityAlerts: true,
      weeklyDigest: false
    },
    security: {
      twoFactorAuth: false,
      apiAccess: true,
      ipWhitelist: '',
      sessionTimeout: 30
    },
    privacy: {
      dataRetentionDays: 365,
      autoRevokeDays: 90,
      auditLogRetention: 2555, // 7 years
      anonymizeData: false
    }
  })

  const handleSave = async () => {
    if (!user) return
    
    try {
      // Update profile in database
      const { error } = await supabase
        .from('profiles')
        .update({
          company_name: settings.profile.companyName,
          contact_email: settings.profile.contactEmail,
          phone: settings.profile.phone,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id)

      if (error) {
        console.error('Error updating profile:', error)
        alert('Failed to save profile settings. Please try again.')
        return
      }

      // Log settings update
      await dbHelpers.logAuditEvent(
        user.id,
        'settings_updated',
        'user_settings',
        'profile_settings',
        {
          updated_fields: Object.keys(settings),
          timestamp: new Date().toISOString()
        }
      )
      
      alert('Settings saved successfully!')
    } catch (error) {
      console.error('Error saving settings:', error)
      alert('Failed to save settings. Please try again.')
    }
  }

  const tabs = [
    { id: 'profile', name: 'Profile', icon: User },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'privacy', name: 'Privacy', icon: Key }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
            <p className="mt-2 text-sm text-gray-600">
              Manage your account preferences and security settings
            </p>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="flex">
              {/* Sidebar */}
              <div className="w-64 border-r border-gray-200">
                <nav className="p-4">
                  {tabs.map((tab) => {
                    const Icon = tab.icon
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md mb-2 ${
                          activeTab === tab.id
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <Icon className="h-5 w-5 mr-3" />
                        {tab.name}
                      </button>
                    )
                  })}
                </nav>
              </div>

              {/* Content */}
              <div className="flex-1 p-6">
                {activeTab === 'profile' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Company Name
                        </label>
                        <input
                          type="text"
                          value={settings.profile.companyName}
                          onChange={(e) => setSettings({
                            ...settings,
                            profile: { ...settings.profile, companyName: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Enter company name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Contact Email
                        </label>
                        <input
                          type="email"
                          value={settings.profile.contactEmail}
                          onChange={(e) => setSettings({
                            ...settings,
                            profile: { ...settings.profile, contactEmail: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          value={settings.profile.phone}
                          onChange={(e) => setSettings({
                            ...settings,
                            profile: { ...settings.profile, phone: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Enter phone number"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Industry
                        </label>
                        <select
                          value={settings.profile.industry}
                          onChange={(e) => setSettings({
                            ...settings,
                            profile: { ...settings.profile, industry: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="fintech">Fintech</option>
                          <option value="banking">Banking</option>
                          <option value="insurance">Insurance</option>
                          <option value="investment">Investment</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'notifications' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Notification Preferences</h3>
                    <div className="space-y-4">
                      {Object.entries(settings.notifications).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                            </p>
                            <p className="text-sm text-gray-500">
                              {key === 'emailAlerts' && 'Receive email notifications for important events'}
                              {key === 'dataAccessNotifications' && 'Get notified when partners access your data'}
                              {key === 'complianceReports' && 'Receive compliance report notifications'}
                              {key === 'securityAlerts' && 'Get alerted about security issues'}
                              {key === 'weeklyDigest' && 'Weekly summary of account activity'}
                            </p>
                          </div>
                          <button
                            onClick={() => setSettings({
                              ...settings,
                              notifications: { ...settings.notifications, [key]: !value }
                            })}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                              value ? 'bg-blue-600' : 'bg-gray-200'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                value ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'security' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Security Settings</h3>
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-900">Two-Factor Authentication</p>
                          <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                        </div>
                        <button className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700">
                          Enable
                        </button>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Session Timeout (minutes)
                        </label>
                        <input
                          type="number"
                          value={settings.security.sessionTimeout}
                          onChange={(e) => setSettings({
                            ...settings,
                            security: { ...settings.security, sessionTimeout: parseInt(e.target.value) }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          min="5"
                          max="120"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          IP Whitelist
                        </label>
                        <textarea
                          value={settings.security.ipWhitelist}
                          onChange={(e) => setSettings({
                            ...settings,
                            security: { ...settings.security, ipWhitelist: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Enter IP addresses, one per line"
                          rows={3}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'privacy' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Privacy Settings</h3>
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Data Retention Period (days)
                        </label>
                        <input
                          type="number"
                          value={settings.privacy.dataRetentionDays}
                          onChange={(e) => setSettings({
                            ...settings,
                            privacy: { ...settings.privacy, dataRetentionDays: parseInt(e.target.value) }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          min="30"
                          max="3650"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Auto-Revoke Inactive Permissions (days)
                        </label>
                        <input
                          type="number"
                          value={settings.privacy.autoRevokeDays}
                          onChange={(e) => setSettings({
                            ...settings,
                            privacy: { ...settings.privacy, autoRevokeDays: parseInt(e.target.value) }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          min="30"
                          max="365"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Audit Log Retention (days)
                        </label>
                        <input
                          type="number"
                          value={settings.privacy.auditLogRetention}
                          onChange={(e) => setSettings({
                            ...settings,
                            privacy: { ...settings.privacy, auditLogRetention: parseInt(e.target.value) }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          min="365"
                          max="3650"
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={handleSave}
                    className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 flex items-center gap-2"
                  >
                    <Save className="h-4 w-4" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
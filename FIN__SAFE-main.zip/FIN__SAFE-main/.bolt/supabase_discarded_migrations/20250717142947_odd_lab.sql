/*
  # Storage Bucket Setup Function
  
  This migration creates a function to help with storage bucket setup
  and provides instructions for manual configuration.
*/

-- Create a function to check storage setup
CREATE OR REPLACE FUNCTION check_storage_setup()
RETURNS TABLE (
  bucket_exists boolean,
  policies_count integer,
  setup_instructions text
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    EXISTS(SELECT 1 FROM storage.buckets WHERE name = 'data-shares') as bucket_exists,
    (SELECT COUNT(*)::integer FROM storage.policies WHERE bucket_id = 'data-shares') as policies_count,
    'Manual setup required: Create bucket "data-shares" in Supabase Dashboard → Storage' as setup_instructions;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION check_storage_setup() TO authenticated;

-- Create sample data for testing (only if tables exist and are empty)
DO $$
BEGIN
  -- Check if we can insert sample data
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'profiles') THEN
    -- Insert sample profiles if none exist
    IF NOT EXISTS (SELECT 1 FROM profiles LIMIT 1) THEN
      INSERT INTO profiles (user_id, company_name, contact_email, phone) VALUES
      ('00000000-0000-0000-0000-000000000001', 'Demo Bank Corp', 'demo@demobank.com', '+1-555-0101'),
      ('00000000-0000-0000-0000-000000000002', 'Sample Credit Union', 'info@samplecu.com', '+1-555-0102')
      ON CONFLICT (user_id) DO NOTHING;
    END IF;
  END IF;

  -- Insert sample data shares if none exist
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'data_shares') THEN
    IF NOT EXISTS (SELECT 1 FROM data_shares LIMIT 1) THEN
      INSERT INTO data_shares (user_id, partner_name, data_type, purpose, status, expires_at, details) VALUES
      ('00000000-0000-0000-0000-000000000001', 'Credit Union Partners', 'Transaction History', 'Credit assessment for loan application', 'active', NOW() + INTERVAL '30 days', '{"upload_method": "manual", "created_via": "demo"}'),
      ('00000000-0000-0000-0000-000000000001', 'Fintech Solutions', 'Account Balance', 'Account verification for digital wallet', 'pending', NOW() + INTERVAL '15 days', '{"upload_method": "manual", "created_via": "demo"}'),
      ('00000000-0000-0000-0000-000000000002', 'Insurance Corp', 'Personal Information', 'Policy underwriting assessment', 'active', NOW() + INTERVAL '60 days', '{"upload_method": "manual", "created_via": "demo"}')
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  -- Insert sample permissions if none exist
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'permissions') THEN
    IF NOT EXISTS (SELECT 1 FROM permissions LIMIT 1) THEN
      INSERT INTO permissions (user_id, partner_id, data_type, granted) VALUES
      ('00000000-0000-0000-0000-000000000001', 'credit_union', 'account_balance', true),
      ('00000000-0000-0000-0000-000000000001', 'credit_union', 'transaction_history', true),
      ('00000000-0000-0000-0000-000000000001', 'fintech_co', 'credit_score', true),
      ('00000000-0000-0000-0000-000000000002', 'insurance_corp', 'personal_info', true),
      ('00000000-0000-0000-0000-000000000002', 'bank_a', 'account_balance', false)
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  -- Insert sample audit logs if none exist
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'audit_logs') THEN
    IF NOT EXISTS (SELECT 1 FROM audit_logs LIMIT 1) THEN
      INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details, ip_address, user_agent) VALUES
      ('00000000-0000-0000-0000-000000000001', 'data_share_created', 'data_share', 'demo-share-1', '{"partner": "Credit Union Partners", "data_type": "Transaction History"}', '192.168.1.100', 'Mozilla/5.0 Demo Browser'),
      ('00000000-0000-0000-0000-000000000001', 'permission_granted', 'permission', 'demo-perm-1', '{"partner": "credit_union", "data_type": "account_balance"}', '192.168.1.100', 'Mozilla/5.0 Demo Browser'),
      ('00000000-0000-0000-0000-000000000002', 'data_access', 'data_share', 'demo-share-2', '{"accessed_by": "Insurance Corp", "data_type": "Personal Information"}', '192.168.1.101', 'Mozilla/5.0 Demo Browser')
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    -- Ignore errors if tables don't exist yet
    NULL;
END;
$$;